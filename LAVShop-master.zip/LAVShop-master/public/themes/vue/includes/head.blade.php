<head>
    <script src="/themes/vue/assets/js/vendor.js"></script>
</head>