<p>
    Order No: {{$order_id}}
</p>

<p>
    {{$content}}
</p>
