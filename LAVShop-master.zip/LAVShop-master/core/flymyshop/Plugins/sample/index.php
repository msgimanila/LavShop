<?php

/**
 * Class Sample.
 */
class Sample
{
    public function __construct()
    {
    }
}
