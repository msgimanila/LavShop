<?php

namespace Flymyshop\Plugins\Sample;

use Flymyshop\Plugins\Plugin;

class Sample implements Plugin
{
    public static function main()
    {
        return 'sample';
    }
}
