<?php

return [
    'welcome' => '',
];
