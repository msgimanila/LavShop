<?php

namespace App\Http\Controllers;

/**
 * Class ThemeController.
 * @category AppControllers
 *
 * @author acev <aasisvinayak@gmail.com>
 * @license https://github.com/aasisvinayak/flymyshop/blob/master/LICENSE  GPL-3.0
 *
 * @link https://github.com/aasisvinayak/flymyshop
 */
class ThemeController extends Controller
{
    public function addTheme()
    {
    }

    public function deleteTheme()
    {
    }

    public function themes()
    {
    }
}
