[![Build Status]( 


# LAVShop

A free open source e-commerce platform for online merchants based on customised version of Laravel.

![LAVShop Demo](/thumbnail.png)

# Overview

LAVShop is a fully fledged e-commerce platform for online merchants. 

- Free and open source
- Users can view, search and buy products
- Admin has the ability to add, edit and remove products, categories and shop pages
- Integrated with Stripe
- Integrated with Telegram messaging (for order update)
- Users can add multiple credit cards to their account
- Social login - Users can login using their facebook account
- Manage orders and payments
- Ability to refund orders
- Throttling to protect against brute force attacks
- reCAPTCHA to prevent abuse
- Newsletter support (Integrated MailChimp)
- Multi-currency support

# Features

- Add custom shop themes
- Add plugins to extend the features (See master branch - v0.0.1 does not offer support for plugins)
- OS independent
- Laravel based

#Automated Installation and Shop Configuration

Please follow the steps below to install FlyMyShop on your web server

a. Download [this zip](https://github.com/msgimanila/LavShop file
b. Unzip and upload to your server
c. Visit the public folder
d. Follow the instructions

Please make sure that only public directory is visible to the outside world!

#  Installation Methods
 
 You can also install FlyMyShop in the following ways as well:

a. Manual

Download the release and follow the steps below:

```
  - cd  core 
  - cp .env.example .env
  - complete .env values (optional)
  - composer install
  - chmod -R 777 storage
  - php artisan key:generate 
  - php artisan migrate  (if prompted say yes)
  - php artisan db:seed (if prompted say yes)
  - php artisan serve --port=8000 --host=localhost &
```

b. Using Composer

```
 

```

c. Docker

```
 
```

Please make sure that Apache is running in your docker container if the shop fails to load.

#Get Started

If you have pull the release via composer, please go to the 'shop' folder and issue

```
php artisan serve --port 8000
```

The application will be available at http://localhost:8000


 


#Database

The default is sqlite and you can change this to any other database as you please. For example, if you wish to use mysql please update the .env file as follows:

```
DB_CONNECTION=mysql
DB_HOST=127.0.0.1		
DB_PORT=3306		
DB_DATABASE=database_name		
DB_USERNAME=username		
DB_PASSWORD=secret

```

#Seed Users

When you install the project, it creates two users for you:

test@example.com and 
user@example.com

The first one is an administrator and the second one a regular user. The default password for both are passw0rd. 
You can manually update the database to update the email.


#Testing

Run the tests with (please make sure the values for testing are filled in correctly in the config/database.php file and .env):

``` bash
vendor/bin/phpunit
```

# How to contribute

If you wish to contribute please fork the repository, edit and submit a pull request.

# License

GNU General Public License version 3 (GPLv3)

# Links

 